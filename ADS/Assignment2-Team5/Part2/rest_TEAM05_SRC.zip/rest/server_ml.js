var express = require('express');
var app = express();
var http = require("http");

var https = require("https");

var querystring = require("querystring");

var fs = require('fs');

var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// configure a public directory to host static content
app.use(express.static(__dirname + '/public'));


var ipaddress = process.env.OPENSHIFT_NODEJS_IP;
var port      = process.env.OPENSHIFT_NODEJS_IPORT || 3000;

app.listen(port, ipaddress);
// app.post("/prediction/neural-network", neuralNetwork);
// app.post("/prediction/linear-regression", linearRegression);
// app.post("/prediction/random-regression",randomForestRegression);
//app.post("/prediction/regression",regression);
app.post("/classification",classification);
//app.post("/clustering",clustering);
//maml-server.js
var result = '';

function classification(req, res){
    var data = {
  "Inputs": {
    "input1": {
      "ColumnNames": [
        "PassengerId",
        "Survived",
        "Pclass",
        "Name",
        "Sex",
        "Age",
        "SibSp",
        "Parch",
        "Ticket",
        "Fare",
        "Cabin",
        "Embarked"
      ],
      "Values": [
        [
          "1000",
          "0",
          "1",
          "rose",
          "female",
          "17",
          "0",
          "2",
          "A12",
          "200",
          "A12",
          "S"
        ],
        [
          "900",
          "0",
          "3",
          "jack",
          "male",
          "19",
          "0",
          "0",
          "C12",
          "0",
          "C12",
          "S"
        ]
      ]
    }
  },
  "GlobalParameters": {}
};
    var path = '/workspaces/895503c96ee3453e8e49e4a6b911d739/services/772c22d842c6491fac4b89b0f168970e/execute?api-version=2.0&details=true';
    var key = 'WGMlMmvm33WsfHWrDOGjPWjO87K8IlHMh6OE1PGiGcnqUIjumrNjR9uqFDn3TDK7D7Ltms+pp22I3VhAkaoA8g==';
    getPred(data, path, key);
    setTimeout(function() {
        console.log(result);
        res.json(result);
    }, 1000);

}


function getPred(data, path, api_key) {

    var dataString = JSON.stringify(data);
    var host = 'ussouthcentral.services.azureml.net';
    var headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + api_key};

    var options = {
        host: host,
        port: 443,
        path: path,
        method: 'POST',
        headers: headers
    };

    result = '';
    var reqPost = https.request(options, function (res) {
        res.on('data', function (d) {
            setTimeout(function() {
                process.stdout.write(d);
                result += d;
            }, 300);
            //return d;
        });
    });

// Would need more parsing out of prediction from the result
    reqPost.write(dataString);
    reqPost.end();
    reqPost.on('error', function (e) {
        console.error(e);

    });
    //console.log(result);
    //return result;
}

function send404Reponse(response) {
    response.writeHead(404, {"Context-Type": "text/plain"});
    response.write("Error 404: Page not Found! Not sure");
    response.end();
}

function onRequest(request, response) {
    if(request.method == 'GET' && request.url == '/' ){
        response.writeHead(200, {"Context-Type": "text/plain"});
        fs.createReadStream("./index.html").pipe(response);
    }else {
        send404Reponse(response);
    }
}

http.createServer(onRequest).listen(8050);
//buildFeatureInput();
